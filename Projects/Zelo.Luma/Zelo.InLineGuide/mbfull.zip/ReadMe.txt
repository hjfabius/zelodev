Modbus ActiveX Automation Server 

Simple freeware ActiveX out-process (*.exe) modbus master for windows. 

This file have 3 zip files:

mfcatl.zip - visual C++ run time files.
mod101.zip - Active X executable and documentation
modscr01.zip - All MS VC++ 6.0 source code.

Visit http://mbserver.w3.to/ for more details about 
this program

Author Ricardo Saat - rsaat@altavista.net 
		      http://mbserver.w3.to/		
